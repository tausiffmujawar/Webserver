from bottle import route, run, template, post, request, response
import os

path = "C:\Hackathon\PyWebserver\TestLogFolder"
rootFolder = 'TestLogFolder'
filetree = dict()


@route('/')
def index():
    filetree = make_tree(path)
    return template('Home.tpl', tree=filetree, current=rootFolder, parent=rootFolder)


def make_tree(path):
    filetree = dict(name=os.path.basename(path), children=[])
    try:
        lst = os.listdir(path)
    except OSError:
        pass  # ignore errors
    else:
        for name in lst:
            fn = os.path.join(path, name)
            if os.path.isdir(fn):
                filetree['children'].append(make_tree(fn))
            else:
                filetree['children'].append(dict(name=name))
    return filetree


@route('/fileClicked', method='GET')
def fileClicked():
    return "File"


@post('/folderClicked')
def folderClicked():
    postBody = request.json
    currentFolder = postBody['currentFolderName']
    parentFolder = postBody['parent']
    return template('Home.tpl', tree=make_tree(path + "\\" + currentFolder), current=currentFolder, parent=parentFolder)


@post('/sendFolderDetails')
def sendFolderDetails():
    postBody = request.json
    return postBody['currentFolderName']


@post('/display')
def display():
    postBody = request.json
    currentFolder = postBody['currentFolderName']
    parentFolder = postBody['parent']
    return template('Home.tpl', tree=make_tree(path + "\\" + currentFolder), current=currentFolder, parent=parentFolder)


run(host='localhost', port=6003)
