#include <iostream>
#include <cstring>

using namespace std;

bool isPalindrome(char str[]){
    bool centerUsed = false;
  char center;

  char c;
  int count = 0;
  // Check each letter to see if there's an even number of it.
  for(int i = 0; i<strlen(str); i++)
  {
    c = str[i];
    count = 0;

    for(int j = 0; j < strlen(str); j++)
      if (str[j] == c)
         count++;

    // If there was an odd number of those entries
    // and the center is already used, then a palindrome
    // is impossible, so return false.
    if (count % 2 == 1)
    {
      if (centerUsed == true && center != c)
        return false;
        
      else
      {
        centerUsed = true;
        center = c;   // This is so when we encounter it again it
                      // doesn't count it as another separate center.
      }
    }
  }
  // If we made it all the way through that loop without returning false, then
  return true;
    
}
int main()
{ 
    char str[] = "maadm";
  bool result = isPalindrome(str);
  if(result){
  cout << "Palindrome";
        }
        else 
        cout << "Not a Palindrome";
    }