from flask import Flask,jsonify,render_template
import os

app = Flask(__name__)
fileList = [] 

@app.route("/")
def home():
    # for root, dirs, files in os.walk("."):
    #     for filename in files:
    #         fileList.append(filename)
    # #return jsonify({'Files': fileList})
    # return render_template("Index.html")
    path = os.getcwd()   
    return render_template('Index.html',tree=make_tree(path))


def make_tree(path):
    tree = dict(name=os.path.basename(path), children=[])
    try: lst = os.listdir(path)
    except OSError:
        pass #ignore errors
    else:
        for name in lst:
            fn = os.path.join(path, name)
            if os.path.isdir(fn):
                tree['children'].append(make_tree(fn))
            else:
                tree['children'].append(dict(name=name))
    return tree


def list_files(startpath):
    fileList = list()
    for root, dirs, files in os.walk(startpath):
        level = root.replace(startpath, '').count(os.sep)
        indent = ' ' * 4 * (level)
        fileList.append('{}{}/'.format(indent, os.path.basename(root)))
        subindent = ' ' * 4 * (level + 1)
        for f in files:
            fileList.append('{}{}'.format(subindent, f))
    return fileList
    
if __name__ == "__main__":
    app.debug = True
    app.run(host = '0.0.0.0',port=5005)