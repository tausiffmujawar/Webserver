from bottle import route, run, template, post, request, response, TEMPLATES
import os
import json

path = "C:\Hackathon\PyWebserver\TestLogFolder"
rootFolder = 'TestLogFolder'
fileList = list()
output = list()


def make_tree(path):
    filetree = dict(name=os.path.basename(path), children=[])
    try:
        lst = os.listdir(path)
    except OSError:
        pass  # ignore errors
    else:
        for name in lst:
            fn = os.path.join(path, name)
            if os.path.isdir(fn):
                filetree['children'].append(make_tree(fn))
            else:
                filetree['children'].append(dict(name=name))
    return filetree


filetree = make_tree(path)


@route('/')
def index():
    return template('Home.tpl', tree=filetree, fileList=fileList, output=output)


@route('/sendFolderDetails', method='GET')
def sendFolderDetails():
    fileList = os.listdir(rootFolder)
    return template('Home.tpl', tree=filetree, fileList=fileList, output=output)


@route('/display', method='GET')
def display():
    output = os.listdir(rootFolder)
    return template('Home.tpl', tree=filetree, fileList=list(), output=output)


run(host='localhost', port=6003)
